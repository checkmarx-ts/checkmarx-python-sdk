# encoding: utf-8

__author__ = 'Checkmarx'
__version__ = '0.0.1'
